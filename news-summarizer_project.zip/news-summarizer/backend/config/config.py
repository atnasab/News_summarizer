MONGO_URI = "mongodb://localhost:27017/"
NEWS_API_KEY = "your_news_api_key_here"
DB_NAME = "news_db"
COLLECTION_NAME = "summarized_news"
